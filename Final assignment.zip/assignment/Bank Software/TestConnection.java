import Core.DBConnection;
import java.sql.Connection;

public class TestConnection {
    public static void main(String[] args) {
        Connection conn = DBConnection.getConnection();
        if (conn != null) {
            System.out.println("🎉 H2 Database connection test passed!");
        } else {
            System.out.println("⚠️ Connection failed.");
        }
    }
}